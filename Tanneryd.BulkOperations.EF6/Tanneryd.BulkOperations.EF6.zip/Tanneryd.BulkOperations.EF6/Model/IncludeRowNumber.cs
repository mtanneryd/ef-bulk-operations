﻿namespace Tanneryd.BulkOperations.EF6.Model
{
    internal enum IncludeRowNumber
    {
        Yes,
        No
    }
}